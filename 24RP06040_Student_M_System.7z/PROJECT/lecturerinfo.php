



<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Home</title>
	<style type="text/css">

		
		*{
			margin: 0;
			padding: 0;
		}
		.head{
		
	
/*		margin-left: 22rem;*/
		justify-content: center;
		background: #1E3A8A;
		color: white;
		font-weight: bold;
		height: 8rem;
		margin-left: 23rem;
		margin-right: 20rem;
		margin-top:0.9rem;
		gap: 1rem;
		display: flex;
		


		}
		a{
		
			text-decoration: none;
			color: gold;
			font-weight: bold ;
			font-family: sans-serif;
			margin-top: 6rem;
			font-size: 1.1rem;
			font-family: sans-serif;

		
			

		}
		.main{
			text-align: center;
			justify-content: center;
			display: flex;
			margin-top: 0.8rem;
			font-weight: bold;
			font-family: sans-serif;
		}
		.left{
			margin-right: 1rem;
			background:;
			color: black;
			width: 28rem;
			height:33.5rem;
			font-family: sans-serif;
			font-size: 1.1rem;


			
		}
		.head a{


		
		    
			
		}
		.right{
			margin-left: 4rem;
			/*color: #2D2D2D;*/
			font-family: sans-serif;
		
		}
		.join{
			font-weight: bold;
			font-size: 1.1rem;
			margin-right: 8rem;
		}
		input{
			background: black;
			color: white;
			border-color: bisque;
			border-radius: 0.2rem;
			width: 13rem;
			height: 1.1rem;
			font-family: sans-serif;
/*			margin-bottom: 1rem;*/
		}
		.footer{
			padding-top: 2rem;
			text-align: center;
			justify-content: center;
			background: #0F172A;
			color: white;
			bottom: 0;
			position: absolute;
			font-family: sans-serif;

			
			height: 3rem;
			font-size: 1.2rem;
			width: 57rem;
			margin-left: 23rem;
	     
      
      

		}
		a:hover{
			color: #14B8A6;
		}
		.kk{
			
		}
	
	</style>
</head>
<body>
<div class="head">
	<h2 style="font-size: 1.1rem;font-family: sans-serif;">TUMBA STUDENT MANAGEMENT SYSTEM</h2><br>
	
	<a href="index.php">Home</a>
	<a href="Studentinfo.php">Students</a>
	<a href="moduleinfo.php">Modules</a>
	<a href="lecturerinfo.php">Lecturers</a>
<!-- <a href="">Report</a> -->

	<a href="logout.php">Logout</a><br>
</div>
<div style="text-align: center;justify-content: center;margin-top: 1.4rem; font-family: sans-serif;font-weight: bold;font-size: 1.2rem;">
<p>MODULES INFORMATION</p>
  </div>

<div class="main">
	<table border="1" style="border-collapse: collapse; width: 57%;margin-left: 3rem;">
		<tr style="font-size: 1rem;font-family: sans-serif; background: black;color: white;">
			<th>L_id</th>
			<th>Firstname</th>
			<th>Lastname</th>
			<th>Gender</th>
			
			<th>Delete</th>
			<th>Update</th>

		</tr>
<?php 

include "conn.php";


$ql=mysqli_query($con,"SELECT * FROM lecturers");
while ($dt=mysqli_fetch_array($ql)) {
	
	echo "<tr>";


 echo"<td>".$dt[0]."</td>";
 echo"<td>".$dt[1]."</td>";
 echo"<td>".$dt[2]."</td>";
 echo"<td>".$dt[3]."</td>";



 echo"<td><a href='lecturer_delete.php?a=".$dt[0]."' class='kk'>Remove</a></td>";
 echo"<td><a href='lecturer_update.php?b=".$dt[0]."&c=".$dt[1]."&d=".$dt[2]."&v=".$dt[3]."' class='kk'>Change</a></td>";


	echo "</tr>";
}



 ?>
  </table><br>

</div>
<div style="text-align:center;font-family: sans-serif;margin-top: 1.2rem;">
	<button><a href='form_insert_lecturers.php'>Add Lecturer</a> </button>
</div>

	
<div class="footer">
	Tumba College &copy; Right 2025 All Reseved!!
	
</div>
</body>
</html>