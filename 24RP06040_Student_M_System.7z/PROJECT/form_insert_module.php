<?php 
include 'conn.php';
if (isset($_POST['sv'])) {

	$n=$_POST['fn'];
	$p=$_POST['ln'];
	$y=$_POST['rn'];
	
	$sql=mysqli_query($con,"INSERT INTO modules VALUES(NULL,'$n','$p','$y')");
	if ($sql) {
		header("location:moduleinfo.php");
	}
	else{
		echo "Not Added Brooo!!";
	}
}



 ?>
 <!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>

	<style>

	h2{
		font-size: 2rem;
		font-family: sans-serif;
		color:#0F172A;
	}
	body{
		background-color: #0F172A;

	}
	form{
		border-radius: 10px;
		height: 25rem;
		width: 30rem;
		background-color: white;
		font-family: sans-serif;
		margin-top: 8rem;
		font-weight: bold;

	}
	input{
		width: 16rem;
			height: 1.5rem;
		background-color: whitesmoke;
		border-radius: 1rem;
		margin-left: 1rem;
	}
	h2 input{

	}

</style>

</head>
<body>

<center>
	
	<form method="POST">
		<h2>ADD MODULES INFO</h2>
		M_Name: <input type="text" name="fn"><br><br>
		M_Credit: <input type="text" name="ln"><br><br>
	    M_code: <input type="text" name="rn"><br><br>
		
		<input type="submit"value="Add Module" name="sv"  style="width: 7rem;height: 2rem;margin-left: 4rem;font-family: sans-serif;font-weight: bold;font-size: 1rem;"><br><br>

	</form>

</body>

</html>