<?php 
include 'conn.php';
if (isset($_POST['sv'])) {

	$n=$_POST['fn'];
	$p=$_POST['ln'];
	$y=$_POST['rn'];
	$h=$_POST['dt'];
	$j=$_POST['cl'];
	$sql=mysqli_query($con,"INSERT INTO students VALUES(NULL,'$n','$p','$y','$h','$j')");
	if ($sql) {
		header("location:studentinfo.php");
	}
	else{
		echo "Not Added Brooo!!";
	}
}

 ?>
