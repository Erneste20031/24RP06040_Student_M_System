<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>

<style>

	h2{
		font-size: 2rem;
		font-family: sans-serif;
		color:#0F172A;
	}
	body{
		background-color: #0F172A;

	}
	form{
		border-radius: 10px;
		height: 20rem;
		width: 30rem;
		background-color: white;
		font-family: sans-serif;
		margin-top: 8rem;
		font-weight: bold;

	}
	input{
		width: 16rem;
		height: 1.5rem;
		background-color: whitesmoke;
		border-radius: 1rem;
		margin-left: 1rem;

	}
	h2 input{

	}

</style>

</head>
<body>

<center>
	
	<form method="POST">
		<h2 style="margin-top: 1.2rem;">LOGIN HERE</h2>
		Usename: <input type="text" name="name"><br><br>
		Password: <input type="password" name="pass"><br><br>
		<input type="submit"value="Login" name="sv" style="width: 7rem;height: 2rem;margin-left: 4rem;font-family: sans-serif;font-weight: bold;"><br><br>

<div class="nn" style="margin-right: 11rem;">
		<p>Don't Have Account !!</p><a href="create.html" style="text-decoration: none;">SignUp Here</a>
	</div>
	</form>

</center>

<?php 
//session_start();
include 'conn.php';
if (isset($_POST['sv'])) {

	$n=$_POST['name'];
	$p=$_POST['pass'];
	$sql=mysqli_query($con,"SELECT * FROM users WHERE uname='$n' AND password='$p'");
	if ($sql -> num_rows >0) {
		
		header("location:index.php");
		$_SESSION['hh']=$p;
	}
	else{
		header("location:create.html");
	}
}

 ?>

</body>
</html>