<?php 
include 'conn.php';
if (isset($_POST['sv'])) {

	$n=$_POST['name'];
	$p=$_POST['pass'];
	$sql=mysqli_query($con,"INSERT INTO users VALUES(NULL,'$n','$p')");
	if ($sql) {
		header("location:login.php");
	}
	else{
		echo "not created";
	}
}

 ?>
