<?php 

$con=mysqli_connect('localhost','root','','m_system');
session_start();
 ?>