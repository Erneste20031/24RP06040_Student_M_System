<?php 

include "conn.php";
$q=$_GET['b'];
$w=$_GET['c'];
$e=$_GET['d'];
$r=$_GET['v'];
$j=$_GET['h'];
$t=$_GET['n'];
 ?>
 <!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>

	<style>

	h2{
		font-size: 2rem;
		font-family: sans-serif;
		color:#0F172A;
	}
	body{
		background-color: #0F172A;

	}
	form{
		border-radius: 10px;
		height: 25rem;
		width: 30rem;
		background-color: white;
		font-family: sans-serif;
		margin-top: 8rem;
		font-weight: bold;

	}
	input{
		width: 16rem;
			height: 1.5rem;
		background-color: whitesmoke;
		border-radius: 1rem;
		margin-left: 1rem;
	}
	h2 input{

	}

</style>

</head>
<body>

<center>
	
	<form method="POST">
		<h2>CHANGE STUDENT INFO</h2>
		S_id: <input type="number" name="id" value="<?php echo $q; ?>"><br><br>
		Firstname: <input type="text" name="fn" value="<?php echo $w; ?>"><br><br>
		Lastname: <input type="text" name="ln" value="<?php echo $e; ?>"><br><br>
	    Reg_No: <input type="text" name="rn" value="<?php echo $r; ?>"><br><br>
		Birth_Date: <input type="date" name="dt" value="<?php echo $j; ?>"><br><br>
		Class: <input type="text" name="cl" value="<?php echo $t; ?>"><br><br>
		<input type="submit"value=" Update student" name="sv"  style="width: 10rem;height: 2rem;margin-left: 4rem;font-family: sans-serif;font-weight: bold;font-size: 1rem;"><br><br>

	</form>

<?php 
//include "conn.php";
if (isset($_POST['sv'])) {
	$aa=$_POST['id'];
	$ab=$_POST['fn'];
	$ac=$_POST['ln'];
	$ad=$_POST['rn'];
	$ae=$_POST['dt'];
	$af=$_POST['cl'];

	$upd=mysqli_query($con,"UPDATE students SET Firstname='$ab',Lastname='$ac',Regno='$ad',Birth_date='$ae',Class='$af' WHERE S_id='$aa'");



	if ($upd) {
		
		header ("location:studentinfo.php");
	}
	else{

		echo "Not Updated";
	}
}


 ?>

</body>

</html>