<?php 

include "conn.php";
$b=$_GET['a'];
$ql=mysqli_query($con,"DELETE FROM modules WHERE mid='$b'");
if ($ql) {
	// code...
	header("location:moduleinfo.php");
}
else{
	echo "Module Not Removed";

}	


 ?>