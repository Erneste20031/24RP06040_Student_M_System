<?php 

include "conn.php";
$b=$_GET['a'];
$ql=mysqli_query($con,"DELETE FROM lecturers WHERE L_id='$b'");
if ($ql) {
	// code...
	header("location:lecturerinfo.php");
}
else{
	echo "lecturerinfo Not Removed";

}	


 ?>