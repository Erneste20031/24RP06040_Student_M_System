<?php 
include "conn.php";
$b=$_GET['a'];
$ql=mysqli_query($con,"DELETE FROM students WHERE S_id='$b'");
if ($ql) {
	// code...
	header("location:studentinfo.php");
}
else{
	echo "Student Not Removed";

}	
 ?>
