<?php 



include "conn.php";
$q=$_GET['b'];
$w=$_GET['c'];
$e=$_GET['d'];
$r=$_GET['v'];

 ?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>

	<style>

	h2{
		font-size: 2rem;
		font-family: sans-serif;
		color:#0F172A;
	}
	body{
		background-color: #0F172A;

	}
	form{
		border-radius: 10px;
		height: 25rem;
		width: 30rem;
		background-color: white;
		font-family: sans-serif;
		margin-top: 8rem;
		font-weight: bold;

	}
	input{
		width: 16rem;
			height: 1.5rem;
		background-color: whitesmoke;
		border-radius: 1rem;
		margin-left: 1rem;
	}
	h2 input{

	}

</style>

</head>
<body>

<center>
	
	<form method="POST">
		<h2>UPDATE MODULES INFO</h2>
		M_id: <input type="number" name="id" value="<?php echo $q; ?>"><br><br>
		M_name: <input type="text" name="fn" value="<?php echo $w; ?>"><br><br>
		M_Credit: <input type="number" name="ln" value="<?php echo $e; ?>"><br><br>
	    M_Code: <input type="text" name="rn" value="<?php echo $r; ?>"><br><br>
		
		<input type="submit"value=" Update Module" name="sv"  style="width: 10rem;height: 2rem;margin-left: 4rem;font-family: sans-serif;font-weight: bold;font-size: 1rem;"><br><br>

	</form>



 <?php 

if (isset($_POST['sv'])) {
	$aa=$_POST['id'];
	$ab=$_POST['fn'];
	$ac=$_POST['ln'];
	$ad=$_POST['rn'];
	

	$upd=mysqli_query($con,"UPDATE modules SET m_name='$ab',m_credit='$ac',m_code='$ad' WHERE mid='$aa'");



	if ($upd) {
		
		header ("location:moduleinfo.php");
	}
	else{

		echo " Module Not Updated";
	}
}


 ?>


</body>

</html>