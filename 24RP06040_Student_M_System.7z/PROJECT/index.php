<?php 
include('conn.php');
//session_start();
if (!isset($_SESSION['hh'])) {

header("location:login.php");
	
}
 ?>




<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Home</title>
	<style type="text/css">

		
		*{
			margin: 0;
			padding: 0;
		}
		.head{
		
	
/*		margin-left: 22rem;*/
		justify-content: center;
		background: #1E3A8A;
		color: white;
		font-weight: bold;
		height: 8rem;
		margin-left: 23rem;
		margin-right: 20rem;
		margin-top:0.9rem;
		gap: 1rem;
		display: flex;
		


		}
		a{
		
			text-decoration: none;
			color: gold;
			font-weight: bold ;
			font-family: sans-serif;
			margin-top: 6rem;
			font-size: 1.1rem;
			font-family: sans-serif;

		
			

		}
		.main{
			text-align: center;
			justify-content: center;
			display: flex;
			margin-top: 0.8rem;
			font-weight: bold;
			font-family: sans-serif;
		}
		.left{
			margin-right: 1rem;
			background:black;
			color: white;
			width: 30rem;
			height:33.5rem;
			font-family: sans-serif;
			font-size: 1.1rem;


			
		}
		.head a{


		
		    
			
		}
		.right{
			margin-left: 4rem;
			/*color: #2D2D2D;*/
			font-family: sans-serif;
		
		}
		.join{
			font-weight: bold;
			font-size: 1.1rem;
			margin-right: 8rem;
		}
		input{
			background: black;
			color: white;
			border-color: bisque;
			border-radius: 0.2rem;
			width: 13rem;
			height: 1.1rem;
			font-family: sans-serif;
/*			margin-bottom: 1rem;*/
		}
		.footer{
			padding-top: 2rem;
			text-align: center;
			justify-content: center;
			background: #0F172A;
			color: white;
			bottom: 0;
			position: absolute;
			font-family: sans-serif;

			width: 57%;
			margin-left: 23rem;
			height: 3rem;
			font-size: 1.2rem;
	     
      
      

		}
		a:hover{
			color: #14B8A6;
		}
	</style>
</head>
<body>
<div class="head">
	<h2 style="font-size: 1.1rem;font-family: sans-serif;">TUMBA STUDENT MANAGEMENT SYSTEM</h2><br>
	
	<a href="index.php">Home</a>
	<a href="studentinfo.php">Students</a>
	<a href="moduleinfo.php">Modules</a>
	<a href="lecturerinfo.php">Lecturers</a>
	<!-- <a href="">Report</a> -->

	<a href="logout.php">Logout</a><br>
</div>

<div class="main">
	<div class="left">
		<h3>TUMBA COLLEGE</h3><br>
		<p>IPRC Tumba is a technical and vocational higher education institution under Rwanda Polytechnic (RP). <br>> It was established by government decision on 14 September 2007 and officially inaugurated in June 2008.</p><br><br>
        <p>Its stated vision: “To be a Center of Excellence in Technical Education in Rwanda and Region.” </p><br>

<p>Programs & Departments:</p><br>

<ol>
    <li>Information & Communication Technology (ICT)</li><br>
    <li>Mechanical Engineering</li><br>
    <li>Electrical & Electronics Engineering</li><br>
    <li>Electronics & Telecommunications</li><br>
    <li>Alternative Energy</li>
</ol>
		
	</div>
	<div class="right">
		<img src="tum.jpeg" width="300rem" height="200rem"><br><br>
		<h4 class="join">JOIN US</h4><br>
		First Name:<br>
		<input type="text" name="" placeholder="Enter Fname"><br>								
		Last Name:<br>
		<input type="text" name="" placeholder="Enter Lname"><br>								
		Email:<br>
		<input type="Email" name="" placeholder="Enter Email"><br>								
		Phone Number:<br>
		<input type="Number" name="" placeholder="Enter Phone Number"><br><br>
		<button type="submit" style="width: 8rem;background: black;color: white;border-radius: 2rem;">Send</button>							
	</div>
</div>
<div class="footer">
	Tumba College &copy; Right 2025 All Reseved!!
	
</div>
</body>
</html>