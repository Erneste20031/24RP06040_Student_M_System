<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>

	<style>

	h2{
		font-size: 2rem;
		font-family: sans-serif;
		color:#0F172A;
	}
	body{
		background-color: #0F172A;

	}
	form{
		border-radius: 10px;
		height: 25rem;
		width: 30rem;
		background-color: white;
		font-family: sans-serif;
		margin-top: 8rem;
		font-weight: bold;

	}
	input{
		width: 16rem;
			height: 1.5rem;
		background-color: whitesmoke;
		border-radius: 1rem;
		margin-left: 1rem;
	}
	h2 input{

	}

</style>

</head>
<body>

<center>
	
	<form method="POST" action="st.php">
		<h2>ADD STUDENT INFO</h2>
		Firstname: <input type="text" name="fn"><br><br>
		Lastname: <input type="text" name="ln"><br><br>
	    Reg_No: <input type="text" name="rn"><br><br>
		Birth_Date: <input type="date" name="dt"><br><br>
		Class: <input type="text" name="cl"><br><br>
		<input type="submit"value="Add student" name="sv"  style="width: 7rem;height: 2rem;margin-left: 4rem;font-family: sans-serif;font-weight: bold;font-size: 1rem;"><br><br>

	</form>



</body>

</html>